# CIDM-6325

echo "# CIDM-6325" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/m3gan-m/CIDM-6325.git
git push -u origin main
