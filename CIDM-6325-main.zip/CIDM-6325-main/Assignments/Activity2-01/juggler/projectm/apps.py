from django.apps import AppConfig


class ProjectmConfig(AppConfig):
    name = 'projectm'
